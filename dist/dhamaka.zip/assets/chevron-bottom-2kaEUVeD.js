import{w as o}from"./core-BZxxaqX5.js";import"./index-DH7ah1ZN.js";import"./index.es-B14tpgIX.js";import"./events-DQ172AOg.js";import"./index-nibyPLVP.js";const p=o`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1.46 4.96a1 1 0 0 1 1.41 0L8 10.09l5.13-5.13a1 1 0 1 1 1.41 1.41l-5.83 5.84a1 1 0 0 1-1.42 0L1.46 6.37a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`;export{p as chevronBottomSvg};
