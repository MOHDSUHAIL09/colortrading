import{w as o}from"./core-DPB94aQu.js";import"./index-D_S2HWRX.js";import"./index.es-CQWjh-g0.js";import"./events-DQ172AOg.js";import"./index-nibyPLVP.js";const p=o`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M9.36 4.21a5.14 5.14 0 1 0 0 10.29 5.14 5.14 0 0 0 0-10.29ZM1.64 9.36a7.71 7.71 0 1 1 14 4.47l2.52 2.5a1.29 1.29 0 1 1-1.82 1.83l-2.51-2.51A7.71 7.71 0 0 1 1.65 9.36Z"
    clip-rule="evenodd"
  />
</svg>`;export{p as searchSvg};
