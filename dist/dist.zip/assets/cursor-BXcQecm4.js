import{w as o}from"./core-DPB94aQu.js";import"./index-D_S2HWRX.js";import"./index.es-CQWjh-g0.js";import"./events-DQ172AOg.js";import"./index-nibyPLVP.js";const l=o` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`;export{l as cursorSvg};
