import{w as o}from"./core-DPB94aQu.js";import"./index-D_S2HWRX.js";import"./index.es-CQWjh-g0.js";import"./events-DQ172AOg.js";import"./index-nibyPLVP.js";const n=o`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.74 3.99a1 1 0 0 1 1-1H11a1 1 0 0 1 1 1v6.26a1 1 0 0 1-2 0V6.4l-6.3 6.3a1 1 0 0 1-1.4-1.42l6.29-6.3H4.74a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`;export{n as externalLinkSvg};
