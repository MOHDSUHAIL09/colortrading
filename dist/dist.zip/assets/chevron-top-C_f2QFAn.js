import{w as o}from"./core-DPB94aQu.js";import"./index-D_S2HWRX.js";import"./index.es-CQWjh-g0.js";import"./events-DQ172AOg.js";import"./index-nibyPLVP.js";const t=o`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.54 11.04a1 1 0 0 1-1.41 0L8 5.92l-5.13 5.12a1 1 0 1 1-1.41-1.41l5.83-5.84a1 1 0 0 1 1.42 0l5.83 5.84a1 1 0 0 1 0 1.41Z"
    clip-rule="evenodd"
  />
</svg>`;export{t as chevronTopSvg};
